-- 💀
local HMCDIcon = "hmcd_icon24.png"
list.Set("ContentCategoryIcons", "JMod - EZ Homicide", HMCDIcon)